package com.examples.java;

public class Person{

	String name;
	Address address;
	

}
