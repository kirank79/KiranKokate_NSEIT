package feb23;

interface Account{
	double getBalaance;
	String name;
	String department;
}

class College implements StudentFunction{
	
	public void rollno() {
		System.out.println();
		System.out.println("STUDENTS ROLL NO IS");
	}
	public void name() {
		System.out.println();
		System.out.println("STUDENTS NAME IS");
		
	}
	public void department() {
		System.out.println();
		System.out.println("STUDENT DEPARTMENT IS");
	}
}


public class Interface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
