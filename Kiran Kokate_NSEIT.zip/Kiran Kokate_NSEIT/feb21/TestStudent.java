package corejavaexamples;

public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student stu1= new Student();
		stu1.setHallTicketNumber(1001);
		stu1.setName("praveen");
		stu1.setBranch("cse");
		stu1.setCollege("JNTU");
		System.out.println(stu1.getBranch());

	}

}
