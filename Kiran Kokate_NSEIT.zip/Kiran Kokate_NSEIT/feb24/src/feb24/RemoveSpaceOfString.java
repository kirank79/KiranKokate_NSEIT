package com.assignment.java;
import java.util.function.*;
import java.util.Scanner;


public class RemoveSpaceOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string");
		String str=sc.nextLine();
		Function<String,String> f1= str1->str1.replaceAll(" ", "");
		String s1=f1.apply(str);
		System.out.println("After removing space:  "+s1);
		
		
	}

}
