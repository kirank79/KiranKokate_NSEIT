package jdbcPrograms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayData {

	public static void main(String [] args) throws SQLException{
		
		DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		
		String url ="jdbc:mysql://localhost:3306/nseit";
		String username ="root";
		String password ="root";
		Connection con = DriverManager.getConnection(url,username,password);
		
		
		Statement st = con.createStatement();
		
		String sql = "Select * from student";
		
		ResultSet rs = st.executeQuery(sql);
		
		
		while (rs.next())
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3));
		
		
		rs.close();
		st.close();
		con.close();
		DriverManager.deregisterDriver(new com.mysql.jdbc.Driver());
		
	}
}
