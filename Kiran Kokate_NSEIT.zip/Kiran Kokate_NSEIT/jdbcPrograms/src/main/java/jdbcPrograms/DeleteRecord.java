package jdbcPrograms;

public class DeleteRecord {

}
