package com.assignment.java;
import java.util.function.*;



import java.util.Scanner;


public class NameStartWithK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		String [] str=new String[5];
		System.out.println("Enter the names");
		for(int i=0;i<str.length;i++) {
			str[i]=sc.next();
		}
		
		Predicate<String> p1=str1->str1.charAt(0)=='k' || str1.charAt(0)=='K';
		System.out.println("The names start with K are: ");
		
		for(String str1:str) {
			if(p1.test(str1)) {
				System.out.println(str1);
			}
		}
	}

}
