package com.examples.java;

public class TestBox3D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box3D box= new Box3D();
		box.calArea();
		box.calVolume();
	}

}
