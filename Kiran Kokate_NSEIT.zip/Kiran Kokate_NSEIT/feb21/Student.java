package corejavaexamples;

public class Student {
	
	private int hallTicketNumber;
    private String name;
    private String branch;
    private String college;
    
	public int getHallTicketNumber() {
		return hallTicketNumber;
	}
	public void setHallTicketNumber(int hallTicketNumber) {
		this.hallTicketNumber = hallTicketNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	
	public void getStudentDetails(){
		// code 
	}
	public void displayStudentDetails(){
		// code
	}

}
