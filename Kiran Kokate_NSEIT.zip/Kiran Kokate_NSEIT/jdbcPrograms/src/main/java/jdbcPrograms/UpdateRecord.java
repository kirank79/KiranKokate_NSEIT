package jdbcPrograms;

public class UpdateRecord {

}
